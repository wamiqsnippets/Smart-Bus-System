package main

import (
	"context"
	"fmt"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/gorilla/mux"
	"github.com/rs/zerolog/log"

	"smart-bus-system/internal/config"
	"smart-bus-system/internal/handler"
	"smart-bus-system/internal/middleware"
	"smart-bus-system/internal/repository"
	"smart-bus-system/internal/service"
	"smart-bus-system/internal/utils"
	"smart-bus-system/pkg/database"
)

func main() {
	// Load configuration
	cfg, err := config.Load()
	if err != nil {
		log.Fatal().Err(err).Msg("Failed to load configuration")
	}

	// Initialize logger
	utils.InitLogger(cfg.App.LogLevel)

	log.Info().
		Str("environment", cfg.App.Environment).
		Str("version", "1.0.0").
		Msg("Starting Smart Bus Student Management System")

	// Connect to database
	db, err := database.NewDatabase(cfg)
	if err != nil {
		log.Fatal().Err(err).Msg("Failed to connect to database")
	}
	defer db.Close()

	// Initialize repositories
	busRepo := repository.NewBusRepository(db.Pool)
	stopRepo := repository.NewStopRepository(db.Pool)
	tripRepo := repository.NewTripRepository(db.Pool)
	studentCountRepo := repository.NewStudentCountRepository(db.Pool)

	// Initialize services
	wsService := service.NewWebSocketService()
	geofenceService := service.NewGeofenceService(
		stopRepo,
		studentCountRepo,
		cfg.App.DuplicateDetectionWindowSec,
	)
	tripService := service.NewTripService(
		tripRepo,
		busRepo,
		studentCountRepo,
		geofenceService,
		wsService,
	)

	// Start background job for cache cleanup
	go startCacheCleanup(geofenceService)

	// Initialize handlers
	tripHandler := handler.NewTripHandler(tripService)
	wsHandler := handler.NewWebSocketHandler(wsService)

	// Setup router
	router := setupRouter(tripHandler, wsHandler)

	// Apply middleware
	router.Use(middleware.Recovery)
	router.Use(middleware.Logger)
	router.Use(middleware.CORS)

	// Create server
	addr := fmt.Sprintf("%s:%s", cfg.Server.Host, cfg.Server.Port)
	server := &http.Server{
		Addr:         addr,
		Handler:      router,
		ReadTimeout:  cfg.Server.ReadTimeout,
		WriteTimeout: cfg.Server.WriteTimeout,
	}

	// Start server in goroutine
	go func() {
		log.Info().Str("address", addr).Msg("Server starting")
		if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Fatal().Err(err).Msg("Server failed to start")
		}
	}()

	// Wait for interrupt signal for graceful shutdown
	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
	<-quit

	log.Info().Msg("Shutting down server...")

	// Graceful shutdown with timeout
	ctx, cancel := context.WithTimeout(context.Background(), cfg.Server.ShutdownTimeout)
	defer cancel()

	if err := server.Shutdown(ctx); err != nil {
		log.Fatal().Err(err).Msg("Server forced to shutdown")
	}

	log.Info().Msg("Server stopped gracefully")
}

func setupRouter(tripHandler *handler.TripHandler, wsHandler *handler.WebSocketHandler) *mux.Router {
	router := mux.NewRouter()

	// API v1 routes
	api := router.PathPrefix("/api/v1").Subrouter()

	// Health check
	api.HandleFunc("/health", healthCheck).Methods("GET")

	// Trip endpoints
	api.HandleFunc("/trips", tripHandler.GetTripsByDate).Methods("GET")
	api.HandleFunc("/trips", tripHandler.CreateTrip).Methods("POST")
	api.HandleFunc("/trips/{id}", tripHandler.GetTripDetails).Methods("GET")
	api.HandleFunc("/trips/{id}/start", tripHandler.StartTrip).Methods("POST")
	api.HandleFunc("/trips/{id}/location", tripHandler.UpdateLocation).Methods("PUT")
	api.HandleFunc("/trips/{id}/counts", tripHandler.RecordStudentCount).Methods("POST")
	api.HandleFunc("/trips/{id}/end", tripHandler.EndTrip).Methods("POST")

	// Student count endpoints
	api.HandleFunc("/counts/{id}", tripHandler.UpdateStudentCount).Methods("PUT")

	// WebSocket endpoint
	router.HandleFunc("/ws", wsHandler.HandleWebSocket)

	return router
}

func healthCheck(w http.ResponseWriter, r *http.Request) {
	utils.RespondJSON(w, http.StatusOK, map[string]interface{}{
		"status":    "healthy",
		"timestamp": time.Now().UTC(),
		"version":   "1.0.0",
	})
}

func startCacheCleanup(geofenceService *service.GeofenceService) {
	ticker := time.NewTicker(5 * time.Minute)
	defer ticker.Stop()

	for range ticker.C {
		geofenceService.CleanupOldCache()
	}
}
