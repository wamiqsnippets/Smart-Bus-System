package database

import (
	"context"
	"fmt"
	"time"

	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/rs/zerolog/log"
	"smart-bus-system/internal/config"
)

type Database struct {
	Pool *pgxpool.Pool
}

func NewDatabase(cfg *config.Config) (*Database, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	poolConfig, err := pgxpool.ParseConfig(cfg.GetDSN())
	if err != nil {
		return nil, fmt.Errorf("failed to parse database config: %w", err)
	}

	// Configure connection pool
	poolConfig.MaxConns = int32(cfg.Database.MaxOpenConns)
	poolConfig.MinConns = int32(cfg.Database.MaxIdleConns)
	poolConfig.MaxConnLifetime = cfg.Database.ConnMaxLifetime
	poolConfig.MaxConnIdleTime = 30 * time.Minute
	poolConfig.HealthCheckPeriod = 1 * time.Minute

	// Create connection pool
	pool, err := pgxpool.NewWithConfig(ctx, poolConfig)
	if err != nil {
		return nil, fmt.Errorf("failed to create connection pool: %w", err)
	}

	// Test connection
	if err := pool.Ping(ctx); err != nil {
		pool.Close()
		return nil, fmt.Errorf("failed to ping database: %w", err)
	}

	log.Info().
		Str("host", cfg.Database.Host).
		Str("database", cfg.Database.DBName).
		Int("max_conns", cfg.Database.MaxOpenConns).
		Msg("Database connection established")

	return &Database{Pool: pool}, nil
}

func (db *Database) Close() {
	if db.Pool != nil {
		db.Pool.Close()
		log.Info().Msg("Database connection closed")
	}
}

func (db *Database) Health(ctx context.Context) error {
	ctx, cancel := context.WithTimeout(ctx, 2*time.Second)
	defer cancel()

	return db.Pool.Ping(ctx)
}

func (db *Database) Stats() map[string]interface{} {
	stats := db.Pool.Stat()
	return map[string]interface{}{
		"acquired_conns":     stats.AcquiredConns(),
		"idle_conns":         stats.IdleConns(),
		"total_conns":        stats.TotalConns(),
		"max_conns":          stats.MaxConns(),
		"acquire_count":      stats.AcquireCount(),
		"acquire_duration":   stats.AcquireDuration(),
		"empty_acquire":      stats.EmptyAcquireCount(),
		"canceled_acquire":   stats.CanceledAcquireCount(),
		"constructed_conns":  stats.ConstructingConns(),
		"max_lifetime_conns": stats.MaxLifetimeDestroyCount(),
		"max_idle_conns":     stats.MaxIdleDestroyCount(),
	}
}
