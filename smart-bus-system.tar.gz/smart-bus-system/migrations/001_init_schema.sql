-- Smart Bus Student Management System - Database Schema
-- Version: 1.0
-- Date: 2025-01-01

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create enum for trip types
CREATE TYPE trip_type AS ENUM ('morning', 'return');

-- Create enum for trip status
CREATE TYPE trip_status AS ENUM ('scheduled', 'in_progress', 'completed', 'cancelled');

-- Buses table
CREATE TABLE buses (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    bus_number VARCHAR(50) UNIQUE NOT NULL,
    capacity INTEGER NOT NULL,
    driver_name VARCHAR(100),
    driver_phone VARCHAR(20),
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Index on bus_number for fast lookups
CREATE INDEX idx_buses_bus_number ON buses(bus_number);
CREATE INDEX idx_buses_is_active ON buses(is_active);

-- Bus stops table with geofencing data
CREATE TABLE bus_stops (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) NOT NULL,
    latitude DECIMAL(10, 8) NOT NULL,
    longitude DECIMAL(11, 8) NOT NULL,
    geofence_radius INTEGER DEFAULT 50, -- radius in meters
    stop_order INTEGER NOT NULL,
    estimated_students INTEGER DEFAULT 0,
    address TEXT,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Spatial index for geofencing queries
CREATE INDEX idx_stops_coordinates ON bus_stops(latitude, longitude);
CREATE INDEX idx_stops_stop_order ON bus_stops(stop_order);
CREATE INDEX idx_stops_is_active ON bus_stops(is_active);

-- Trips table (one per day per bus)
CREATE TABLE trips (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    bus_id UUID NOT NULL REFERENCES buses(id) ON DELETE CASCADE,
    trip_date DATE NOT NULL,
    trip_type trip_type NOT NULL,
    status trip_status DEFAULT 'scheduled',
    start_time TIMESTAMP WITH TIME ZONE,
    end_time TIMESTAMP WITH TIME ZONE,
    current_latitude DECIMAL(10, 8),
    current_longitude DECIMAL(11, 8),
    last_location_update TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(bus_id, trip_date, trip_type)
);

-- Indexes for trip queries
CREATE INDEX idx_trips_bus_id ON trips(bus_id);
CREATE INDEX idx_trips_trip_date ON trips(trip_date);
CREATE INDEX idx_trips_status ON trips(status);
CREATE INDEX idx_trips_bus_date_type ON trips(bus_id, trip_date, trip_type);

-- Student counts at each stop during trips
CREATE TABLE student_counts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    trip_id UUID NOT NULL REFERENCES trips(id) ON DELETE CASCADE,
    stop_id UUID NOT NULL REFERENCES bus_stops(id) ON DELETE CASCADE,
    students_boarded INTEGER DEFAULT 0,
    students_alighted INTEGER DEFAULT 0,
    manual_override BOOLEAN DEFAULT false,
    arrival_time TIMESTAMP WITH TIME ZONE,
    departure_time TIMESTAMP WITH TIME ZONE,
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(trip_id, stop_id)
);

-- Indexes for fast lookups
CREATE INDEX idx_student_counts_trip_id ON student_counts(trip_id);
CREATE INDEX idx_student_counts_stop_id ON student_counts(stop_id);
CREATE INDEX idx_student_counts_trip_stop ON student_counts(trip_id, stop_id);

-- Location tracking history (for debugging and analytics)
CREATE TABLE location_history (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    trip_id UUID NOT NULL REFERENCES trips(id) ON DELETE CASCADE,
    latitude DECIMAL(10, 8) NOT NULL,
    longitude DECIMAL(11, 8) NOT NULL,
    accuracy FLOAT,
    speed FLOAT,
    recorded_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Partition by date for performance (monthly partitions)
CREATE INDEX idx_location_history_trip_id ON location_history(trip_id);
CREATE INDEX idx_location_history_recorded_at ON location_history(recorded_at DESC);

-- Geofence detection events (for duplicate prevention)
CREATE TABLE geofence_events (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    trip_id UUID NOT NULL REFERENCES trips(id) ON DELETE CASCADE,
    stop_id UUID NOT NULL REFERENCES bus_stops(id) ON DELETE CASCADE,
    event_type VARCHAR(20) NOT NULL, -- 'enter' or 'exit'
    detected_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    latitude DECIMAL(10, 8) NOT NULL,
    longitude DECIMAL(11, 8) NOT NULL
);

CREATE INDEX idx_geofence_events_trip_id ON geofence_events(trip_id);
CREATE INDEX idx_geofence_events_stop_id ON geofence_events(stop_id);
CREATE INDEX idx_geofence_events_detected_at ON geofence_events(detected_at DESC);
CREATE INDEX idx_geofence_events_trip_stop_type ON geofence_events(trip_id, stop_id, event_type);

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Triggers for updated_at
CREATE TRIGGER update_buses_updated_at BEFORE UPDATE ON buses
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_bus_stops_updated_at BEFORE UPDATE ON bus_stops
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_trips_updated_at BEFORE UPDATE ON trips
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_student_counts_updated_at BEFORE UPDATE ON student_counts
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Sample data for testing
INSERT INTO buses (bus_number, capacity, driver_name, driver_phone) VALUES
    ('BUS-001', 50, 'John Smith', '+1234567890'),
    ('BUS-002', 45, 'Jane Doe', '+1234567891');

INSERT INTO bus_stops (name, latitude, longitude, geofence_radius, stop_order, estimated_students, address) VALUES
    ('Main Gate', 28.6139, 77.2090, 50, 1, 10, '123 Main Street'),
    ('North Campus', 28.6189, 77.2140, 50, 2, 15, '456 North Ave'),
    ('South Park', 28.6089, 77.2040, 50, 3, 12, '789 South Blvd'),
    ('East Gardens', 28.6139, 77.2190, 50, 4, 8, '321 East Road'),
    ('West Plaza', 28.6139, 76.9990, 50, 5, 14, '654 West Lane');

-- Create view for trip summaries
CREATE OR REPLACE VIEW trip_summaries AS
SELECT 
    t.id,
    t.trip_date,
    t.trip_type,
    t.status,
    b.bus_number,
    COUNT(DISTINCT sc.stop_id) as stops_visited,
    SUM(sc.students_boarded) as total_boarded,
    SUM(sc.students_alighted) as total_alighted,
    t.start_time,
    t.end_time
FROM trips t
JOIN buses b ON t.bus_id = b.id
LEFT JOIN student_counts sc ON t.id = sc.trip_id
GROUP BY t.id, t.trip_date, t.trip_type, t.status, b.bus_number, t.start_time, t.end_time;

-- Performance optimization: Analyze tables
ANALYZE buses;
ANALYZE bus_stops;
ANALYZE trips;
ANALYZE student_counts;
ANALYZE location_history;
ANALYZE geofence_events;
