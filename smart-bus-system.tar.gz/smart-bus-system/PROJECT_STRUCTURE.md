# Smart Bus Student Management System - Project Structure

```
smart-bus-system/
├── cmd/
│   └── api/
│       └── main.go                 # Application entry point
├── internal/
│   ├── config/
│   │   └── config.go              # Configuration management
│   ├── models/
│   │   ├── bus.go                 # Bus model
│   │   ├── stop.go                # Stop model
│   │   ├── trip.go                # Trip model
│   │   └── student_count.go       # Student count model
│   ├── repository/
│   │   ├── bus_repository.go      # Bus data access
│   │   ├── stop_repository.go     # Stop data access
│   │   ├── trip_repository.go     # Trip data access
│   │   └── repository.go          # Repository interface
│   ├── service/
│   │   ├── bus_service.go         # Bus business logic
│   │   ├── geofence_service.go    # Geofencing logic
│   │   ├── trip_service.go        # Trip management
│   │   └── websocket_service.go   # Real-time updates
│   ├── handler/
│   │   ├── bus_handler.go         # Bus HTTP handlers
│   │   ├── trip_handler.go        # Trip HTTP handlers
│   │   └── websocket_handler.go   # WebSocket handlers
│   ├── middleware/
│   │   ├── logger.go              # Request logging
│   │   ├── recovery.go            # Panic recovery
│   │   └── cors.go                # CORS handling
│   └── utils/
│       ├── logger.go              # Structured logging
│       ├── response.go            # Standard responses
│       └── geo.go                 # Geolocation utilities
├── migrations/
│   └── 001_init_schema.sql       # Database schema
├── pkg/
│   └── database/
│       └── postgres.go            # Database connection
├── .env.example                   # Environment variables template
├── go.mod                         # Go module definition
├── go.sum                         # Go dependencies
├── Makefile                       # Build and run commands
├── docker-compose.yml             # Docker setup
└── README.md                      # Project documentation
```
