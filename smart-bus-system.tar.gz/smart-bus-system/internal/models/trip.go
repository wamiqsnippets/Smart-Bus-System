package models

import (
	"time"
)

type TripType string
type TripStatus string

const (
	TripTypeMorning TripType = "morning"
	TripTypeReturn  TripType = "return"
)

const (
	TripStatusScheduled  TripStatus = "scheduled"
	TripStatusInProgress TripStatus = "in_progress"
	TripStatusCompleted  TripStatus = "completed"
	TripStatusCancelled  TripStatus = "cancelled"
)

type Trip struct {
	ID                 string     `json:"id"`
	BusID              string     `json:"bus_id"`
	TripDate           time.Time  `json:"trip_date"`
	TripType           TripType   `json:"trip_type"`
	Status             TripStatus `json:"status"`
	StartTime          *time.Time `json:"start_time,omitempty"`
	EndTime            *time.Time `json:"end_time,omitempty"`
	CurrentLatitude    *float64   `json:"current_latitude,omitempty"`
	CurrentLongitude   *float64   `json:"current_longitude,omitempty"`
	LastLocationUpdate *time.Time `json:"last_location_update,omitempty"`
	CreatedAt          time.Time  `json:"created_at"`
	UpdatedAt          time.Time  `json:"updated_at"`
}

type TripWithDetails struct {
	Trip
	BusNumber      string         `json:"bus_number"`
	StudentCounts  []StudentCount `json:"student_counts,omitempty"`
	TotalBoarded   int            `json:"total_boarded"`
	TotalAlighted  int            `json:"total_alighted"`
	StopsVisited   int            `json:"stops_visited"`
}

type CreateTripRequest struct {
	BusID    string   `json:"bus_id" validate:"required,uuid"`
	TripDate string   `json:"trip_date" validate:"required"` // YYYY-MM-DD
	TripType TripType `json:"trip_type" validate:"required,oneof=morning return"`
}

type StartTripRequest struct {
	Latitude  float64 `json:"latitude" validate:"required,min=-90,max=90"`
	Longitude float64 `json:"longitude" validate:"required,min=-180,max=180"`
}

type UpdateLocationRequest struct {
	Latitude  float64  `json:"latitude" validate:"required,min=-90,max=90"`
	Longitude float64  `json:"longitude" validate:"required,min=-180,max=180"`
	Accuracy  *float64 `json:"accuracy,omitempty"`
	Speed     *float64 `json:"speed,omitempty"`
}

type EndTripRequest struct {
	Latitude  float64 `json:"latitude" validate:"required,min=-90,max=90"`
	Longitude float64 `json:"longitude" validate:"required,min=-180,max=180"`
}

type LocationHistory struct {
	ID         string    `json:"id"`
	TripID     string    `json:"trip_id"`
	Latitude   float64   `json:"latitude"`
	Longitude  float64   `json:"longitude"`
	Accuracy   *float64  `json:"accuracy,omitempty"`
	Speed      *float64  `json:"speed,omitempty"`
	RecordedAt time.Time `json:"recorded_at"`
}
