package models

import (
	"time"
)

type StudentCount struct {
	ID               string     `json:"id"`
	TripID           string     `json:"trip_id"`
	StopID           string     `json:"stop_id"`
	StudentsBoarded  int        `json:"students_boarded"`
	StudentsAlighted int        `json:"students_alighted"`
	ManualOverride   bool       `json:"manual_override"`
	ArrivalTime      *time.Time `json:"arrival_time,omitempty"`
	DepartureTime    *time.Time `json:"departure_time,omitempty"`
	Notes            string     `json:"notes,omitempty"`
	CreatedAt        time.Time  `json:"created_at"`
	UpdatedAt        time.Time  `json:"updated_at"`
}

type StudentCountWithStop struct {
	StudentCount
	StopName      string  `json:"stop_name"`
	StopLatitude  float64 `json:"stop_latitude"`
	StopLongitude float64 `json:"stop_longitude"`
	StopOrder     int     `json:"stop_order"`
}

type RecordStudentCountRequest struct {
	StopID           string `json:"stop_id" validate:"required,uuid"`
	StudentsBoarded  int    `json:"students_boarded" validate:"min=0"`
	StudentsAlighted int    `json:"students_alighted" validate:"min=0"`
	Notes            string `json:"notes,omitempty"`
}

type UpdateStudentCountRequest struct {
	StudentsBoarded  *int    `json:"students_boarded,omitempty" validate:"omitempty,min=0"`
	StudentsAlighted *int    `json:"students_alighted,omitempty" validate:"omitempty,min=0"`
	ManualOverride   *bool   `json:"manual_override,omitempty"`
	Notes            *string `json:"notes,omitempty"`
}

type GeofenceEvent struct {
	ID          string    `json:"id"`
	TripID      string    `json:"trip_id"`
	StopID      string    `json:"stop_id"`
	EventType   string    `json:"event_type"` // "enter" or "exit"
	DetectedAt  time.Time `json:"detected_at"`
	Latitude    float64   `json:"latitude"`
	Longitude   float64   `json:"longitude"`
}

type StopDetectionResult struct {
	StopID             string    `json:"stop_id"`
	StopName           string    `json:"stop_name"`
	Distance           float64   `json:"distance"` // meters
	IsWithinGeofence   bool      `json:"is_within_geofence"`
	ExpectedStudents   int       `json:"expected_students"`
	AlreadyRecorded    bool      `json:"already_recorded"`
	DetectionTime      time.Time `json:"detection_time"`
}
