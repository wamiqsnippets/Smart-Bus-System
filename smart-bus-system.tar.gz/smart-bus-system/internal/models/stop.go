package models

import (
	"time"
)

type BusStop struct {
	ID                string    `json:"id"`
	Name              string    `json:"name"`
	Latitude          float64   `json:"latitude"`
	Longitude         float64   `json:"longitude"`
	GeofenceRadius    int       `json:"geofence_radius"` // meters
	StopOrder         int       `json:"stop_order"`
	EstimatedStudents int       `json:"estimated_students"`
	Address           string    `json:"address,omitempty"`
	IsActive          bool      `json:"is_active"`
	CreatedAt         time.Time `json:"created_at"`
	UpdatedAt         time.Time `json:"updated_at"`
}

type CreateStopRequest struct {
	Name              string  `json:"name" validate:"required"`
	Latitude          float64 `json:"latitude" validate:"required,min=-90,max=90"`
	Longitude         float64 `json:"longitude" validate:"required,min=-180,max=180"`
	GeofenceRadius    int     `json:"geofence_radius" validate:"min=10,max=500"`
	StopOrder         int     `json:"stop_order" validate:"required,min=1"`
	EstimatedStudents int     `json:"estimated_students" validate:"min=0"`
	Address           string  `json:"address"`
}

type UpdateStopRequest struct {
	Name              *string  `json:"name,omitempty"`
	Latitude          *float64 `json:"latitude,omitempty" validate:"omitempty,min=-90,max=90"`
	Longitude         *float64 `json:"longitude,omitempty" validate:"omitempty,min=-180,max=180"`
	GeofenceRadius    *int     `json:"geofence_radius,omitempty" validate:"omitempty,min=10,max=500"`
	StopOrder         *int     `json:"stop_order,omitempty" validate:"omitempty,min=1"`
	EstimatedStudents *int     `json:"estimated_students,omitempty" validate:"omitempty,min=0"`
	Address           *string  `json:"address,omitempty"`
	IsActive          *bool    `json:"is_active,omitempty"`
}
