package models

import (
	"time"
)

type Bus struct {
	ID          string    `json:"id"`
	BusNumber   string    `json:"bus_number"`
	Capacity    int       `json:"capacity"`
	DriverName  string    `json:"driver_name,omitempty"`
	DriverPhone string    `json:"driver_phone,omitempty"`
	IsActive    bool      `json:"is_active"`
	CreatedAt   time.Time `json:"created_at"`
	UpdatedAt   time.Time `json:"updated_at"`
}

type CreateBusRequest struct {
	BusNumber   string `json:"bus_number" validate:"required"`
	Capacity    int    `json:"capacity" validate:"required,min=1"`
	DriverName  string `json:"driver_name"`
	DriverPhone string `json:"driver_phone"`
}

type UpdateBusRequest struct {
	Capacity    *int    `json:"capacity,omitempty" validate:"omitempty,min=1"`
	DriverName  *string `json:"driver_name,omitempty"`
	DriverPhone *string `json:"driver_phone,omitempty"`
	IsActive    *bool   `json:"is_active,omitempty"`
}
