package service

import (
	"context"
	"fmt"
	"sync"
	"time"

	"github.com/google/uuid"
	"github.com/rs/zerolog/log"
	"smart-bus-system/internal/models"
	"smart-bus-system/internal/repository"
	"smart-bus-system/internal/utils"
)

// GeofenceService handles geofencing logic with duplicate detection
type GeofenceService struct {
	stopRepo         repository.StopRepository
	studentCountRepo repository.StudentCountRepository
	duplicateWindow  int // seconds
	
	// In-memory cache for performance (optional, with mutex for concurrency safety)
	recentDetections sync.Map // key: "tripID:stopID" -> time.Time
}

func NewGeofenceService(
	stopRepo repository.StopRepository,
	studentCountRepo repository.StudentCountRepository,
	duplicateWindowSec int,
) *GeofenceService {
	return &GeofenceService{
		stopRepo:         stopRepo,
		studentCountRepo: studentCountRepo,
		duplicateWindow:  duplicateWindowSec,
	}
}

// DetectStops finds all stops within geofence range and checks if already visited
// Returns stops that should be processed
func (s *GeofenceService) DetectStops(ctx context.Context, tripID string, lat, lon float64, maxRadiusMeters float64) ([]models.StopDetectionResult, error) {
	// Find nearby stops using optimized spatial query
	stops, err := s.stopRepo.FindNearbyStops(ctx, lat, lon, maxRadiusMeters)
	if err != nil {
		return nil, fmt.Errorf("failed to find nearby stops: %w", err)
	}

	if len(stops) == 0 {
		return []models.StopDetectionResult{}, nil
	}

	var results []models.StopDetectionResult
	
	// Process each detected stop
	for _, stop := range stops {
		// Calculate precise distance
		distance := utils.HaversineDistance(lat, lon, stop.Latitude, stop.Longitude)
		
		// Check if within stop's specific geofence radius
		isWithin := distance <= float64(stop.GeofenceRadius)
		
		if !isWithin {
			continue // Skip stops outside their geofence
		}

		// Check if this stop was already visited (duplicate detection)
		alreadyRecorded, err := s.IsStopAlreadyVisited(ctx, tripID, stop.ID)
		if err != nil {
			log.Warn().Err(err).
				Str("trip_id", tripID).
				Str("stop_id", stop.ID).
				Msg("Failed to check if stop already visited")
			// Continue processing even if check fails
		}

		result := models.StopDetectionResult{
			StopID:           stop.ID,
			StopName:         stop.Name,
			Distance:         distance,
			IsWithinGeofence: isWithin,
			ExpectedStudents: stop.EstimatedStudents,
			AlreadyRecorded:  alreadyRecorded,
			DetectionTime:    time.Now(),
		}
		
		results = append(results, result)
	}

	return results, nil
}

// IsStopAlreadyVisited checks if a stop was recently visited to prevent duplicates
// Uses both database check and in-memory cache for performance
func (s *GeofenceService) IsStopAlreadyVisited(ctx context.Context, tripID, stopID string) (bool, error) {
	cacheKey := fmt.Sprintf("%s:%s", tripID, stopID)
	
	// Check in-memory cache first (O(1) operation)
	if lastDetection, ok := s.recentDetections.Load(cacheKey); ok {
		if time.Since(lastDetection.(time.Time)) < time.Duration(s.duplicateWindow)*time.Second {
			return true, nil
		}
	}

	// Check database for geofence events within the time window
	hasRecent, err := s.studentCountRepo.HasRecentEntry(ctx, tripID, stopID, s.duplicateWindow)
	if err != nil {
		return false, err
	}

	if hasRecent {
		// Update cache
		s.recentDetections.Store(cacheKey, time.Now())
	}

	return hasRecent, nil
}

// RecordGeofenceEntry records when a bus enters a stop's geofence
// This is called BEFORE recording student counts
func (s *GeofenceService) RecordGeofenceEntry(ctx context.Context, tripID, stopID string, lat, lon float64) error {
	event := &models.GeofenceEvent{
		ID:         uuid.New().String(),
		TripID:     tripID,
		StopID:     stopID,
		EventType:  "enter",
		DetectedAt: time.Now(),
		Latitude:   lat,
		Longitude:  lon,
	}

	if err := s.studentCountRepo.SaveGeofenceEvent(ctx, event); err != nil {
		return fmt.Errorf("failed to record geofence entry: %w", err)
	}

	// Update in-memory cache
	cacheKey := fmt.Sprintf("%s:%s", tripID, stopID)
	s.recentDetections.Store(cacheKey, time.Now())

	log.Info().
		Str("trip_id", tripID).
		Str("stop_id", stopID).
		Float64("latitude", lat).
		Float64("longitude", lon).
		Msg("Geofence entry recorded")

	return nil
}

// RecordGeofenceExit records when a bus exits a stop's geofence
func (s *GeofenceService) RecordGeofenceExit(ctx context.Context, tripID, stopID string, lat, lon float64) error {
	event := &models.GeofenceEvent{
		ID:         uuid.New().String(),
		TripID:     tripID,
		StopID:     stopID,
		EventType:  "exit",
		DetectedAt: time.Now(),
		Latitude:   lat,
		Longitude:  lon,
	}

	if err := s.studentCountRepo.SaveGeofenceEvent(ctx, event); err != nil {
		return fmt.Errorf("failed to record geofence exit: %w", err)
	}

	log.Info().
		Str("trip_id", tripID).
		Str("stop_id", stopID).
		Msg("Geofence exit recorded")

	return nil
}

// GetStopForReturnTrip calculates expected alighting students for a stop during return trip
// Based on morning trip boarding data
func (s *GeofenceService) GetStopForReturnTrip(ctx context.Context, morningTripID, stopID string) (int, error) {
	// Get the student count from the morning trip for this stop
	count, err := s.studentCountRepo.GetByTripAndStop(ctx, morningTripID, stopID)
	if err != nil {
		// If no data found, return 0 students
		return 0, nil
	}

	// Return the number of students who boarded in the morning
	// They should alight during the return trip
	return count.StudentsBoarded, nil
}

// CleanupOldCache removes old entries from in-memory cache
// Should be called periodically
func (s *GeofenceService) CleanupOldCache() {
	cutoff := time.Now().Add(-time.Duration(s.duplicateWindow) * time.Second)
	
	s.recentDetections.Range(func(key, value interface{}) bool {
		if timestamp, ok := value.(time.Time); ok {
			if timestamp.Before(cutoff) {
				s.recentDetections.Delete(key)
			}
		}
		return true
	})
	
	log.Debug().Msg("Geofence cache cleanup completed")
}
