package service

import (
	"context"
	"fmt"
	"time"

	"github.com/google/uuid"
	"github.com/rs/zerolog/log"
	"smart-bus-system/internal/models"
	"smart-bus-system/internal/repository"
)

type TripService struct {
	tripRepo         repository.TripRepository
	busRepo          repository.BusRepository
	studentCountRepo repository.StudentCountRepository
	geofenceService  *GeofenceService
	wsService        *WebSocketService
}

func NewTripService(
	tripRepo repository.TripRepository,
	busRepo repository.BusRepository,
	studentCountRepo repository.StudentCountRepository,
	geofenceService *GeofenceService,
	wsService *WebSocketService,
) *TripService {
	return &TripService{
		tripRepo:         tripRepo,
		busRepo:          busRepo,
		studentCountRepo: studentCountRepo,
		geofenceService:  geofenceService,
		wsService:        wsService,
	}
}

func (s *TripService) CreateTrip(ctx context.Context, req *models.CreateTripRequest) (*models.Trip, error) {
	// Validate bus exists
	bus, err := s.busRepo.GetByID(ctx, req.BusID)
	if err != nil {
		return nil, fmt.Errorf("invalid bus: %w", err)
	}

	if !bus.IsActive {
		return nil, fmt.Errorf("bus is not active")
	}

	// Parse trip date
	tripDate, err := time.Parse("2006-01-02", req.TripDate)
	if err != nil {
		return nil, fmt.Errorf("invalid trip date format: %w", err)
	}

	// Check if trip already exists
	existing, err := s.tripRepo.GetByBusAndDate(ctx, req.BusID, tripDate, req.TripType)
	if err == nil && existing != nil {
		return nil, fmt.Errorf("trip already exists for this bus, date, and type")
	}

	trip := &models.Trip{
		ID:       uuid.New().String(),
		BusID:    req.BusID,
		TripDate: tripDate,
		TripType: req.TripType,
		Status:   models.TripStatusScheduled,
	}

	if err := s.tripRepo.Create(ctx, trip); err != nil {
		return nil, fmt.Errorf("failed to create trip: %w", err)
	}

	log.Info().
		Str("trip_id", trip.ID).
		Str("bus_id", trip.BusID).
		Str("trip_type", string(trip.TripType)).
		Msg("Trip created")

	return trip, nil
}

func (s *TripService) StartTrip(ctx context.Context, tripID string, req *models.StartTripRequest) (*models.Trip, error) {
	trip, err := s.tripRepo.GetByID(ctx, tripID)
	if err != nil {
		return nil, err
	}

	if trip.Status != models.TripStatusScheduled {
		return nil, fmt.Errorf("trip cannot be started in current status: %s", trip.Status)
	}

	now := time.Now()
	trip.Status = models.TripStatusInProgress
	trip.StartTime = &now
	trip.CurrentLatitude = &req.Latitude
	trip.CurrentLongitude = &req.Longitude
	trip.LastLocationUpdate = &now

	if err := s.tripRepo.Update(ctx, tripID, trip); err != nil {
		return nil, fmt.Errorf("failed to start trip: %w", err)
	}

	// Save location history
	history := &models.LocationHistory{
		ID:         uuid.New().String(),
		TripID:     tripID,
		Latitude:   req.Latitude,
		Longitude:  req.Longitude,
		RecordedAt: now,
	}
	if err := s.tripRepo.SaveLocationHistory(ctx, history); err != nil {
		log.Warn().Err(err).Msg("Failed to save location history")
	}

	// Broadcast update via WebSocket
	s.wsService.BroadcastTripUpdate(trip)

	log.Info().
		Str("trip_id", tripID).
		Msg("Trip started")

	return trip, nil
}

func (s *TripService) UpdateLocation(ctx context.Context, tripID string, req *models.UpdateLocationRequest) (*models.Trip, []models.StopDetectionResult, error) {
	trip, err := s.tripRepo.GetByID(ctx, tripID)
	if err != nil {
		return nil, nil, err
	}

	if trip.Status != models.TripStatusInProgress {
		return nil, nil, fmt.Errorf("trip is not in progress")
	}

	// Update location
	if err := s.tripRepo.UpdateLocation(ctx, tripID, req.Latitude, req.Longitude); err != nil {
		return nil, nil, fmt.Errorf("failed to update location: %w", err)
	}

	// Save location history
	history := &models.LocationHistory{
		ID:         uuid.New().String(),
		TripID:     tripID,
		Latitude:   req.Latitude,
		Longitude:  req.Longitude,
		Accuracy:   req.Accuracy,
		Speed:      req.Speed,
		RecordedAt: time.Now(),
	}
	if err := s.tripRepo.SaveLocationHistory(ctx, history); err != nil {
		log.Warn().Err(err).Msg("Failed to save location history")
	}

	// Detect nearby stops using geofencing
	detectedStops, err := s.geofenceService.DetectStops(ctx, tripID, req.Latitude, req.Longitude, 100)
	if err != nil {
		log.Error().Err(err).Msg("Failed to detect stops")
		// Don't fail the location update if geofence detection fails
	}

	// Update trip object for return
	trip.CurrentLatitude = &req.Latitude
	trip.CurrentLongitude = &req.Longitude
	now := time.Now()
	trip.LastLocationUpdate = &now

	// Broadcast location update
	s.wsService.BroadcastLocationUpdate(tripID, req.Latitude, req.Longitude, detectedStops)

	return trip, detectedStops, nil
}

func (s *TripService) RecordStudentCount(ctx context.Context, tripID string, req *models.RecordStudentCountRequest) (*models.StudentCount, error) {
	trip, err := s.tripRepo.GetByID(ctx, tripID)
	if err != nil {
		return nil, err
	}

	if trip.Status != models.TripStatusInProgress {
		return nil, fmt.Errorf("trip is not in progress")
	}

	// Check if count already exists for this stop
	existing, err := s.studentCountRepo.GetByTripAndStop(ctx, tripID, req.StopID)
	if err == nil && existing != nil {
		return nil, fmt.Errorf("student count already recorded for this stop")
	}

	now := time.Now()
	count := &models.StudentCount{
		ID:               uuid.New().String(),
		TripID:           tripID,
		StopID:           req.StopID,
		StudentsBoarded:  req.StudentsBoarded,
		StudentsAlighted: req.StudentsAlighted,
		ManualOverride:   false,
		ArrivalTime:      &now,
		Notes:            req.Notes,
	}

	if err := s.studentCountRepo.Create(ctx, count); err != nil {
		return nil, fmt.Errorf("failed to record student count: %w", err)
	}

	// Record geofence entry if location is available
	if trip.CurrentLatitude != nil && trip.CurrentLongitude != nil {
		if err := s.geofenceService.RecordGeofenceEntry(ctx, tripID, req.StopID, *trip.CurrentLatitude, *trip.CurrentLongitude); err != nil {
			log.Warn().Err(err).Msg("Failed to record geofence entry")
		}
	}

	// Broadcast update
	s.wsService.BroadcastStudentCountUpdate(count)

	log.Info().
		Str("trip_id", tripID).
		Str("stop_id", req.StopID).
		Int("boarded", req.StudentsBoarded).
		Int("alighted", req.StudentsAlighted).
		Msg("Student count recorded")

	return count, nil
}

func (s *TripService) UpdateStudentCount(ctx context.Context, countID string, req *models.UpdateStudentCountRequest) (*models.StudentCount, error) {
	count, err := s.studentCountRepo.GetByID(ctx, countID)
	if err != nil {
		return nil, err
	}

	// Apply updates
	if req.StudentsBoarded != nil {
		count.StudentsBoarded = *req.StudentsBoarded
	}
	if req.StudentsAlighted != nil {
		count.StudentsAlighted = *req.StudentsAlighted
	}
	if req.ManualOverride != nil {
		count.ManualOverride = *req.ManualOverride
	}
	if req.Notes != nil {
		count.Notes = *req.Notes
	}

	now := time.Now()
	count.DepartureTime = &now

	if err := s.studentCountRepo.Update(ctx, countID, count); err != nil {
		return nil, fmt.Errorf("failed to update student count: %w", err)
	}

	s.wsService.BroadcastStudentCountUpdate(count)

	log.Info().
		Str("count_id", countID).
		Bool("manual_override", count.ManualOverride).
		Msg("Student count updated")

	return count, nil
}

func (s *TripService) EndTrip(ctx context.Context, tripID string, req *models.EndTripRequest) (*models.Trip, error) {
	trip, err := s.tripRepo.GetByID(ctx, tripID)
	if err != nil {
		return nil, err
	}

	if trip.Status != models.TripStatusInProgress {
		return nil, fmt.Errorf("trip is not in progress")
	}

	now := time.Now()
	trip.Status = models.TripStatusCompleted
	trip.EndTime = &now
	trip.CurrentLatitude = &req.Latitude
	trip.CurrentLongitude = &req.Longitude

	if err := s.tripRepo.Update(ctx, tripID, trip); err != nil {
		return nil, fmt.Errorf("failed to end trip: %w", err)
	}

	// Broadcast update
	s.wsService.BroadcastTripUpdate(trip)

	log.Info().
		Str("trip_id", tripID).
		Msg("Trip completed")

	return trip, nil
}

func (s *TripService) GetTripDetails(ctx context.Context, tripID string) (*models.TripWithDetails, error) {
	trip, err := s.tripRepo.GetByID(ctx, tripID)
	if err != nil {
		return nil, err
	}

	bus, err := s.busRepo.GetByID(ctx, trip.BusID)
	if err != nil {
		return nil, err
	}

	counts, err := s.studentCountRepo.GetByTripID(ctx, tripID)
	if err != nil {
		return nil, fmt.Errorf("failed to get student counts: %w", err)
	}

	// Calculate totals
	var totalBoarded, totalAlighted int
	for _, count := range counts {
		totalBoarded += count.StudentsBoarded
		totalAlighted += count.StudentsAlighted
	}

	details := &models.TripWithDetails{
		Trip:          *trip,
		BusNumber:     bus.BusNumber,
		TotalBoarded:  totalBoarded,
		TotalAlighted: totalAlighted,
		StopsVisited:  len(counts),
	}

	// Convert StudentCountWithStop to StudentCount for the details
	for _, c := range counts {
		details.StudentCounts = append(details.StudentCounts, c.StudentCount)
	}

	return details, nil
}

func (s *TripService) GetTripsByDate(ctx context.Context, date time.Time) ([]models.TripWithDetails, error) {
	return s.tripRepo.GetTripsByDate(ctx, date)
}
