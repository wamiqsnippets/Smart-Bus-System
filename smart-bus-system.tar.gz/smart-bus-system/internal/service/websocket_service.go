package service

import (
	"encoding/json"
	"net/http"
	"sync"
	"time"

	"github.com/gorilla/websocket"
	"github.com/rs/zerolog/log"
	"smart-bus-system/internal/models"
)

type WebSocketService struct {
	clients    map[*websocket.Conn]bool
	clientsMux sync.RWMutex
	upgrader   websocket.Upgrader
}

type WSMessage struct {
	Type      string      `json:"type"`
	Data      interface{} `json:"data"`
	Timestamp time.Time   `json:"timestamp"`
}

func NewWebSocketService() *WebSocketService {
	return &WebSocketService{
		clients: make(map[*websocket.Conn]bool),
		upgrader: websocket.Upgrader{
			ReadBufferSize:  1024,
			WriteBufferSize: 1024,
			CheckOrigin: func(r *http.Request) bool {
				return true // Configure appropriately for production
			},
		},
	}
}

func (s *WebSocketService) AddClient(conn *websocket.Conn) {
	s.clientsMux.Lock()
	defer s.clientsMux.Unlock()
	s.clients[conn] = true
	log.Info().Msg("WebSocket client connected")
}

func (s *WebSocketService) RemoveClient(conn *websocket.Conn) {
	s.clientsMux.Lock()
	defer s.clientsMux.Unlock()
	delete(s.clients, conn)
	conn.Close()
	log.Info().Msg("WebSocket client disconnected")
}

func (s *WebSocketService) broadcast(message WSMessage) {
	s.clientsMux.RLock()
	defer s.clientsMux.RUnlock()

	data, err := json.Marshal(message)
	if err != nil {
		log.Error().Err(err).Msg("Failed to marshal WebSocket message")
		return
	}

	for client := range s.clients {
		err := client.WriteMessage(websocket.TextMessage, data)
		if err != nil {
			log.Error().Err(err).Msg("Failed to send WebSocket message")
			client.Close()
			delete(s.clients, client)
		}
	}
}

func (s *WebSocketService) BroadcastTripUpdate(trip *models.Trip) {
	message := WSMessage{
		Type:      "trip_update",
		Data:      trip,
		Timestamp: time.Now(),
	}
	s.broadcast(message)
}

func (s *WebSocketService) BroadcastLocationUpdate(tripID string, lat, lon float64, detectedStops []models.StopDetectionResult) {
	data := map[string]interface{}{
		"trip_id":        tripID,
		"latitude":       lat,
		"longitude":      lon,
		"detected_stops": detectedStops,
	}
	message := WSMessage{
		Type:      "location_update",
		Data:      data,
		Timestamp: time.Now(),
	}
	s.broadcast(message)
}

func (s *WebSocketService) BroadcastStudentCountUpdate(count *models.StudentCount) {
	message := WSMessage{
		Type:      "student_count_update",
		Data:      count,
		Timestamp: time.Now(),
	}
	s.broadcast(message)
}

func (s *WebSocketService) BroadcastStopDetection(tripID string, stops []models.StopDetectionResult) {
	data := map[string]interface{}{
		"trip_id": tripID,
		"stops":   stops,
	}
	message := WSMessage{
		Type:      "stop_detection",
		Data:      data,
		Timestamp: time.Now(),
	}
	s.broadcast(message)
}

func (s *WebSocketService) GetClientCount() int {
	s.clientsMux.RLock()
	defer s.clientsMux.RUnlock()
	return len(s.clients)
}
