package handler

import (
	"encoding/json"
	"net/http"
	"time"

	"github.com/gorilla/mux"
	"github.com/rs/zerolog/log"
	"smart-bus-system/internal/models"
	"smart-bus-system/internal/service"
	"smart-bus-system/internal/utils"
)

type TripHandler struct {
	tripService *service.TripService
}

func NewTripHandler(tripService *service.TripService) *TripHandler {
	return &TripHandler{
		tripService: tripService,
	}
}

// CreateTrip godoc
// @Summary Create a new trip
// @Description Create a new trip for a bus on a specific date
// @Tags trips
// @Accept json
// @Produce json
// @Param request body models.CreateTripRequest true "Trip details"
// @Success 201 {object} utils.APIResponse{data=models.Trip}
// @Router /api/v1/trips [post]
func (h *TripHandler) CreateTrip(w http.ResponseWriter, r *http.Request) {
	var req models.CreateTripRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		utils.BadRequest(w, "Invalid request body", err.Error())
		return
	}

	trip, err := h.tripService.CreateTrip(r.Context(), &req)
	if err != nil {
		log.Error().Err(err).Msg("Failed to create trip")
		utils.InternalServerError(w, err.Error())
		return
	}

	utils.RespondJSON(w, http.StatusCreated, trip)
}

// StartTrip godoc
// @Summary Start a trip
// @Description Start an existing trip with initial location
// @Tags trips
// @Accept json
// @Produce json
// @Param id path string true "Trip ID"
// @Param request body models.StartTripRequest true "Start location"
// @Success 200 {object} utils.APIResponse{data=models.Trip}
// @Router /api/v1/trips/{id}/start [post]
func (h *TripHandler) StartTrip(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	tripID := vars["id"]

	var req models.StartTripRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		utils.BadRequest(w, "Invalid request body", err.Error())
		return
	}

	trip, err := h.tripService.StartTrip(r.Context(), tripID, &req)
	if err != nil {
		log.Error().Err(err).Str("trip_id", tripID).Msg("Failed to start trip")
		utils.InternalServerError(w, err.Error())
		return
	}

	utils.RespondJSON(w, http.StatusOK, trip)
}

// UpdateLocation godoc
// @Summary Update trip location
// @Description Update the current location of an active trip and detect nearby stops
// @Tags trips
// @Accept json
// @Produce json
// @Param id path string true "Trip ID"
// @Param request body models.UpdateLocationRequest true "Location data"
// @Success 200 {object} utils.APIResponse
// @Router /api/v1/trips/{id}/location [put]
func (h *TripHandler) UpdateLocation(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	tripID := vars["id"]

	var req models.UpdateLocationRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		utils.BadRequest(w, "Invalid request body", err.Error())
		return
	}

	trip, detectedStops, err := h.tripService.UpdateLocation(r.Context(), tripID, &req)
	if err != nil {
		log.Error().Err(err).Str("trip_id", tripID).Msg("Failed to update location")
		utils.InternalServerError(w, err.Error())
		return
	}

	response := map[string]interface{}{
		"trip":           trip,
		"detected_stops": detectedStops,
	}

	utils.RespondJSON(w, http.StatusOK, response)
}

// RecordStudentCount godoc
// @Summary Record student count at a stop
// @Description Record number of students boarding/alighting at a stop
// @Tags trips
// @Accept json
// @Produce json
// @Param id path string true "Trip ID"
// @Param request body models.RecordStudentCountRequest true "Student count data"
// @Success 201 {object} utils.APIResponse{data=models.StudentCount}
// @Router /api/v1/trips/{id}/counts [post]
func (h *TripHandler) RecordStudentCount(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	tripID := vars["id"]

	var req models.RecordStudentCountRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		utils.BadRequest(w, "Invalid request body", err.Error())
		return
	}

	count, err := h.tripService.RecordStudentCount(r.Context(), tripID, &req)
	if err != nil {
		log.Error().Err(err).Str("trip_id", tripID).Msg("Failed to record student count")
		utils.InternalServerError(w, err.Error())
		return
	}

	utils.RespondJSON(w, http.StatusCreated, count)
}

// UpdateStudentCount godoc
// @Summary Update student count
// @Description Update an existing student count record (manual override)
// @Tags trips
// @Accept json
// @Produce json
// @Param id path string true "Student Count ID"
// @Param request body models.UpdateStudentCountRequest true "Updated count data"
// @Success 200 {object} utils.APIResponse{data=models.StudentCount}
// @Router /api/v1/counts/{id} [put]
func (h *TripHandler) UpdateStudentCount(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	countID := vars["id"]

	var req models.UpdateStudentCountRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		utils.BadRequest(w, "Invalid request body", err.Error())
		return
	}

	count, err := h.tripService.UpdateStudentCount(r.Context(), countID, &req)
	if err != nil {
		log.Error().Err(err).Str("count_id", countID).Msg("Failed to update student count")
		utils.InternalServerError(w, err.Error())
		return
	}

	utils.RespondJSON(w, http.StatusOK, count)
}

// EndTrip godoc
// @Summary End a trip
// @Description Complete an active trip with final location
// @Tags trips
// @Accept json
// @Produce json
// @Param id path string true "Trip ID"
// @Param request body models.EndTripRequest true "End location"
// @Success 200 {object} utils.APIResponse{data=models.Trip}
// @Router /api/v1/trips/{id}/end [post]
func (h *TripHandler) EndTrip(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	tripID := vars["id"]

	var req models.EndTripRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		utils.BadRequest(w, "Invalid request body", err.Error())
		return
	}

	trip, err := h.tripService.EndTrip(r.Context(), tripID, &req)
	if err != nil {
		log.Error().Err(err).Str("trip_id", tripID).Msg("Failed to end trip")
		utils.InternalServerError(w, err.Error())
		return
	}

	utils.RespondJSON(w, http.StatusOK, trip)
}

// GetTripDetails godoc
// @Summary Get trip details
// @Description Get detailed information about a specific trip
// @Tags trips
// @Produce json
// @Param id path string true "Trip ID"
// @Success 200 {object} utils.APIResponse{data=models.TripWithDetails}
// @Router /api/v1/trips/{id} [get]
func (h *TripHandler) GetTripDetails(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	tripID := vars["id"]

	details, err := h.tripService.GetTripDetails(r.Context(), tripID)
	if err != nil {
		log.Error().Err(err).Str("trip_id", tripID).Msg("Failed to get trip details")
		utils.NotFound(w, "Trip not found")
		return
	}

	utils.RespondJSON(w, http.StatusOK, details)
}

// GetTripsByDate godoc
// @Summary Get trips by date
// @Description Get all trips for a specific date
// @Tags trips
// @Produce json
// @Param date query string true "Date in YYYY-MM-DD format"
// @Success 200 {object} utils.APIResponse{data=[]models.TripWithDetails}
// @Router /api/v1/trips [get]
func (h *TripHandler) GetTripsByDate(w http.ResponseWriter, r *http.Request) {
	dateStr := r.URL.Query().Get("date")
	if dateStr == "" {
		dateStr = time.Now().Format("2006-01-02")
	}

	date, err := time.Parse("2006-01-02", dateStr)
	if err != nil {
		utils.BadRequest(w, "Invalid date format", "Use YYYY-MM-DD format")
		return
	}

	trips, err := h.tripService.GetTripsByDate(r.Context(), date)
	if err != nil {
		log.Error().Err(err).Str("date", dateStr).Msg("Failed to get trips by date")
		utils.InternalServerError(w, err.Error())
		return
	}

	utils.RespondJSON(w, http.StatusOK, trips)
}
