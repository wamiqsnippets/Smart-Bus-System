package handler

import (
	"net/http"

	"github.com/rs/zerolog/log"
	"smart-bus-system/internal/service"
)

type WebSocketHandler struct {
	wsService *service.WebSocketService
}

func NewWebSocketHandler(wsService *service.WebSocketService) *WebSocketHandler {
	return &WebSocketHandler{
		wsService: wsService,
	}
}

// HandleWebSocket handles WebSocket connections for real-time updates
func (h *WebSocketHandler) HandleWebSocket(w http.ResponseWriter, r *http.Request) {
	conn, err := h.wsService.upgrader.Upgrade(w, r, nil)
	if err != nil {
		log.Error().Err(err).Msg("Failed to upgrade WebSocket connection")
		return
	}

	h.wsService.AddClient(conn)

	// Keep connection alive and handle disconnection
	defer h.wsService.RemoveClient(conn)

	for {
		// Read messages (mainly for keeping connection alive)
		_, _, err := conn.ReadMessage()
		if err != nil {
			log.Debug().Err(err).Msg("WebSocket read error")
			break
		}
	}
}
