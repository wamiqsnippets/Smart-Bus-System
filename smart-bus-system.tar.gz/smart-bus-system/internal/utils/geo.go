package utils

import (
	"math"
)

const (
	earthRadiusMeters = 6371000 // Earth's radius in meters
)

// HaversineDistance calculates the distance between two geographic coordinates in meters
// Uses the Haversine formula for great-circle distance
// Optimized for performance with minimal allocations
func HaversineDistance(lat1, lon1, lat2, lon2 float64) float64 {
	// Convert to radians
	lat1Rad := degreesToRadians(lat1)
	lat2Rad := degreesToRadians(lat2)
	deltaLat := degreesToRadians(lat2 - lat1)
	deltaLon := degreesToRadians(lon2 - lon1)

	// Haversine formula
	a := math.Sin(deltaLat/2)*math.Sin(deltaLat/2) +
		math.Cos(lat1Rad)*math.Cos(lat2Rad)*
			math.Sin(deltaLon/2)*math.Sin(deltaLon/2)

	c := 2 * math.Atan2(math.Sqrt(a), math.Sqrt(1-a))

	return earthRadiusMeters * c
}

// IsWithinRadius checks if a point is within a given radius of a center point
// O(1) operation
func IsWithinRadius(centerLat, centerLon, pointLat, pointLon float64, radiusMeters float64) bool {
	distance := HaversineDistance(centerLat, centerLon, pointLat, pointLon)
	return distance <= radiusMeters
}

// degreesToRadians converts degrees to radians
func degreesToRadians(degrees float64) float64 {
	return degrees * math.Pi / 180
}

// radiansToDegrees converts radians to degrees
func radiansToDegrees(radians float64) float64 {
	return radians * 180 / math.Pi
}

// BoundingBox calculates a bounding box around a point given a radius in meters
// Returns (minLat, maxLat, minLon, maxLon)
// Useful for optimizing database queries
func BoundingBox(lat, lon float64, radiusMeters float64) (float64, float64, float64, float64) {
	// Angular distance in radians on a great circle
	radDist := radiusMeters / earthRadiusMeters

	latRad := degreesToRadians(lat)
	lonRad := degreesToRadians(lon)

	minLat := latRad - radDist
	maxLat := latRad + radDist

	// Longitude calculation with adjustment for latitude
	deltaLon := math.Asin(math.Sin(radDist) / math.Cos(latRad))
	minLon := lonRad - deltaLon
	maxLon := lonRad + deltaLon

	return radiansToDegrees(minLat),
		radiansToDegrees(maxLat),
		radiansToDegrees(minLon),
		radiansToDegrees(maxLon)
}

// ValidateCoordinates checks if latitude and longitude are valid
func ValidateCoordinates(lat, lon float64) bool {
	return lat >= -90 && lat <= 90 && lon >= -180 && lon <= 180
}
