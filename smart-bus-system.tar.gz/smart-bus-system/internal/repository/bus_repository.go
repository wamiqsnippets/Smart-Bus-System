package repository

import (
	"context"
	"errors"
	"fmt"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
	"smart-bus-system/internal/models"
)

type busRepository struct {
	db *pgxpool.Pool
}

func NewBusRepository(db *pgxpool.Pool) BusRepository {
	return &busRepository{db: db}
}

func (r *busRepository) Create(ctx context.Context, bus *models.Bus) error {
	query := `
		INSERT INTO buses (id, bus_number, capacity, driver_name, driver_phone, is_active)
		VALUES ($1, $2, $3, $4, $5, $6)
		RETURNING created_at, updated_at`

	err := r.db.QueryRow(ctx, query,
		bus.ID,
		bus.BusNumber,
		bus.Capacity,
		bus.DriverName,
		bus.DriverPhone,
		bus.IsActive,
	).Scan(&bus.CreatedAt, &bus.UpdatedAt)

	if err != nil {
		return fmt.Errorf("failed to create bus: %w", err)
	}

	return nil
}

func (r *busRepository) GetByID(ctx context.Context, id string) (*models.Bus, error) {
	query := `
		SELECT id, bus_number, capacity, driver_name, driver_phone, is_active, created_at, updated_at
		FROM buses
		WHERE id = $1`

	var bus models.Bus
	err := r.db.QueryRow(ctx, query, id).Scan(
		&bus.ID,
		&bus.BusNumber,
		&bus.Capacity,
		&bus.DriverName,
		&bus.DriverPhone,
		&bus.IsActive,
		&bus.CreatedAt,
		&bus.UpdatedAt,
	)

	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return nil, fmt.Errorf("bus not found")
		}
		return nil, fmt.Errorf("failed to get bus: %w", err)
	}

	return &bus, nil
}

func (r *busRepository) GetByBusNumber(ctx context.Context, busNumber string) (*models.Bus, error) {
	query := `
		SELECT id, bus_number, capacity, driver_name, driver_phone, is_active, created_at, updated_at
		FROM buses
		WHERE bus_number = $1`

	var bus models.Bus
	err := r.db.QueryRow(ctx, query, busNumber).Scan(
		&bus.ID,
		&bus.BusNumber,
		&bus.Capacity,
		&bus.DriverName,
		&bus.DriverPhone,
		&bus.IsActive,
		&bus.CreatedAt,
		&bus.UpdatedAt,
	)

	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return nil, fmt.Errorf("bus not found")
		}
		return nil, fmt.Errorf("failed to get bus: %w", err)
	}

	return &bus, nil
}

func (r *busRepository) GetAll(ctx context.Context, activeOnly bool) ([]models.Bus, error) {
	query := `
		SELECT id, bus_number, capacity, driver_name, driver_phone, is_active, created_at, updated_at
		FROM buses`

	if activeOnly {
		query += " WHERE is_active = true"
	}

	query += " ORDER BY bus_number"

	rows, err := r.db.Query(ctx, query)
	if err != nil {
		return nil, fmt.Errorf("failed to get buses: %w", err)
	}
	defer rows.Close()

	var buses []models.Bus
	for rows.Next() {
		var bus models.Bus
		err := rows.Scan(
			&bus.ID,
			&bus.BusNumber,
			&bus.Capacity,
			&bus.DriverName,
			&bus.DriverPhone,
			&bus.IsActive,
			&bus.CreatedAt,
			&bus.UpdatedAt,
		)
		if err != nil {
			return nil, fmt.Errorf("failed to scan bus: %w", err)
		}
		buses = append(buses, bus)
	}

	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("rows iteration error: %w", err)
	}

	return buses, nil
}

func (r *busRepository) Update(ctx context.Context, id string, bus *models.Bus) error {
	query := `
		UPDATE buses
		SET capacity = $2, driver_name = $3, driver_phone = $4, is_active = $5
		WHERE id = $1
		RETURNING updated_at`

	err := r.db.QueryRow(ctx, query,
		id,
		bus.Capacity,
		bus.DriverName,
		bus.DriverPhone,
		bus.IsActive,
	).Scan(&bus.UpdatedAt)

	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return fmt.Errorf("bus not found")
		}
		return fmt.Errorf("failed to update bus: %w", err)
	}

	return nil
}

func (r *busRepository) Delete(ctx context.Context, id string) error {
	query := `DELETE FROM buses WHERE id = $1`

	result, err := r.db.Exec(ctx, query, id)
	if err != nil {
		return fmt.Errorf("failed to delete bus: %w", err)
	}

	if result.RowsAffected() == 0 {
		return fmt.Errorf("bus not found")
	}

	return nil
}
