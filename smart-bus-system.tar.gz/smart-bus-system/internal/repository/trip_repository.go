package repository

import (
	"context"
	"errors"
	"fmt"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
	"smart-bus-system/internal/models"
)

type tripRepository struct {
	db *pgxpool.Pool
}

func NewTripRepository(db *pgxpool.Pool) TripRepository {
	return &tripRepository{db: db}
}

func (r *tripRepository) Create(ctx context.Context, trip *models.Trip) error {
	query := `
		INSERT INTO trips (id, bus_id, trip_date, trip_type, status, start_time, end_time, current_latitude, current_longitude, last_location_update)
		VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
		RETURNING created_at, updated_at`

	err := r.db.QueryRow(ctx, query,
		trip.ID,
		trip.BusID,
		trip.TripDate,
		trip.TripType,
		trip.Status,
		trip.StartTime,
		trip.EndTime,
		trip.CurrentLatitude,
		trip.CurrentLongitude,
		trip.LastLocationUpdate,
	).Scan(&trip.CreatedAt, &trip.UpdatedAt)

	if err != nil {
		return fmt.Errorf("failed to create trip: %w", err)
	}

	return nil
}

func (r *tripRepository) GetByID(ctx context.Context, id string) (*models.Trip, error) {
	query := `
		SELECT id, bus_id, trip_date, trip_type, status, start_time, end_time, 
		       current_latitude, current_longitude, last_location_update, created_at, updated_at
		FROM trips
		WHERE id = $1`

	var trip models.Trip
	err := r.db.QueryRow(ctx, query, id).Scan(
		&trip.ID,
		&trip.BusID,
		&trip.TripDate,
		&trip.TripType,
		&trip.Status,
		&trip.StartTime,
		&trip.EndTime,
		&trip.CurrentLatitude,
		&trip.CurrentLongitude,
		&trip.LastLocationUpdate,
		&trip.CreatedAt,
		&trip.UpdatedAt,
	)

	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return nil, fmt.Errorf("trip not found")
		}
		return nil, fmt.Errorf("failed to get trip: %w", err)
	}

	return &trip, nil
}

func (r *tripRepository) GetByBusAndDate(ctx context.Context, busID string, tripDate time.Time, tripType models.TripType) (*models.Trip, error) {
	query := `
		SELECT id, bus_id, trip_date, trip_type, status, start_time, end_time, 
		       current_latitude, current_longitude, last_location_update, created_at, updated_at
		FROM trips
		WHERE bus_id = $1 AND trip_date = $2 AND trip_type = $3`

	var trip models.Trip
	err := r.db.QueryRow(ctx, query, busID, tripDate, tripType).Scan(
		&trip.ID,
		&trip.BusID,
		&trip.TripDate,
		&trip.TripType,
		&trip.Status,
		&trip.StartTime,
		&trip.EndTime,
		&trip.CurrentLatitude,
		&trip.CurrentLongitude,
		&trip.LastLocationUpdate,
		&trip.CreatedAt,
		&trip.UpdatedAt,
	)

	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return nil, fmt.Errorf("trip not found")
		}
		return nil, fmt.Errorf("failed to get trip: %w", err)
	}

	return &trip, nil
}

func (r *tripRepository) GetTripsByDate(ctx context.Context, tripDate time.Time) ([]models.TripWithDetails, error) {
	query := `
		SELECT t.id, t.bus_id, t.trip_date, t.trip_type, t.status, t.start_time, t.end_time,
		       t.current_latitude, t.current_longitude, t.last_location_update, t.created_at, t.updated_at,
		       b.bus_number,
		       COUNT(DISTINCT sc.stop_id) as stops_visited,
		       COALESCE(SUM(sc.students_boarded), 0) as total_boarded,
		       COALESCE(SUM(sc.students_alighted), 0) as total_alighted
		FROM trips t
		JOIN buses b ON t.bus_id = b.id
		LEFT JOIN student_counts sc ON t.id = sc.trip_id
		WHERE t.trip_date = $1
		GROUP BY t.id, t.bus_id, t.trip_date, t.trip_type, t.status, t.start_time, t.end_time,
		         t.current_latitude, t.current_longitude, t.last_location_update, t.created_at, t.updated_at, b.bus_number
		ORDER BY t.trip_type, b.bus_number`

	rows, err := r.db.Query(ctx, query, tripDate)
	if err != nil {
		return nil, fmt.Errorf("failed to get trips by date: %w", err)
	}
	defer rows.Close()

	var trips []models.TripWithDetails
	for rows.Next() {
		var trip models.TripWithDetails
		err := rows.Scan(
			&trip.ID,
			&trip.BusID,
			&trip.TripDate,
			&trip.TripType,
			&trip.Status,
			&trip.StartTime,
			&trip.EndTime,
			&trip.CurrentLatitude,
			&trip.CurrentLongitude,
			&trip.LastLocationUpdate,
			&trip.CreatedAt,
			&trip.UpdatedAt,
			&trip.BusNumber,
			&trip.StopsVisited,
			&trip.TotalBoarded,
			&trip.TotalAlighted,
		)
		if err != nil {
			return nil, fmt.Errorf("failed to scan trip: %w", err)
		}
		trips = append(trips, trip)
	}

	return trips, nil
}

func (r *tripRepository) GetActiveTripForBus(ctx context.Context, busID string) (*models.Trip, error) {
	query := `
		SELECT id, bus_id, trip_date, trip_type, status, start_time, end_time, 
		       current_latitude, current_longitude, last_location_update, created_at, updated_at
		FROM trips
		WHERE bus_id = $1 AND status = 'in_progress'
		ORDER BY created_at DESC
		LIMIT 1`

	var trip models.Trip
	err := r.db.QueryRow(ctx, query, busID).Scan(
		&trip.ID,
		&trip.BusID,
		&trip.TripDate,
		&trip.TripType,
		&trip.Status,
		&trip.StartTime,
		&trip.EndTime,
		&trip.CurrentLatitude,
		&trip.CurrentLongitude,
		&trip.LastLocationUpdate,
		&trip.CreatedAt,
		&trip.UpdatedAt,
	)

	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return nil, fmt.Errorf("no active trip found")
		}
		return nil, fmt.Errorf("failed to get active trip: %w", err)
	}

	return &trip, nil
}

func (r *tripRepository) Update(ctx context.Context, id string, trip *models.Trip) error {
	query := `
		UPDATE trips
		SET status = $2, start_time = $3, end_time = $4, 
		    current_latitude = $5, current_longitude = $6, last_location_update = $7
		WHERE id = $1
		RETURNING updated_at`

	err := r.db.QueryRow(ctx, query,
		id,
		trip.Status,
		trip.StartTime,
		trip.EndTime,
		trip.CurrentLatitude,
		trip.CurrentLongitude,
		trip.LastLocationUpdate,
	).Scan(&trip.UpdatedAt)

	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return fmt.Errorf("trip not found")
		}
		return fmt.Errorf("failed to update trip: %w", err)
	}

	return nil
}

func (r *tripRepository) UpdateLocation(ctx context.Context, id string, lat, lon float64) error {
	query := `
		UPDATE trips
		SET current_latitude = $2, current_longitude = $3, last_location_update = $4
		WHERE id = $1`

	now := time.Now()
	_, err := r.db.Exec(ctx, query, id, lat, lon, now)
	if err != nil {
		return fmt.Errorf("failed to update location: %w", err)
	}

	return nil
}

func (r *tripRepository) UpdateStatus(ctx context.Context, id string, status models.TripStatus) error {
	query := `
		UPDATE trips
		SET status = $2
		WHERE id = $1`

	_, err := r.db.Exec(ctx, query, id, status)
	if err != nil {
		return fmt.Errorf("failed to update status: %w", err)
	}

	return nil
}

func (r *tripRepository) Delete(ctx context.Context, id string) error {
	query := `DELETE FROM trips WHERE id = $1`

	result, err := r.db.Exec(ctx, query, id)
	if err != nil {
		return fmt.Errorf("failed to delete trip: %w", err)
	}

	if result.RowsAffected() == 0 {
		return fmt.Errorf("trip not found")
	}

	return nil
}

func (r *tripRepository) SaveLocationHistory(ctx context.Context, history *models.LocationHistory) error {
	query := `
		INSERT INTO location_history (id, trip_id, latitude, longitude, accuracy, speed, recorded_at)
		VALUES ($1, $2, $3, $4, $5, $6, $7)`

	_, err := r.db.Exec(ctx, query,
		history.ID,
		history.TripID,
		history.Latitude,
		history.Longitude,
		history.Accuracy,
		history.Speed,
		history.RecordedAt,
	)

	if err != nil {
		return fmt.Errorf("failed to save location history: %w", err)
	}

	return nil
}

func (r *tripRepository) GetLocationHistory(ctx context.Context, tripID string, limit int) ([]models.LocationHistory, error) {
	query := `
		SELECT id, trip_id, latitude, longitude, accuracy, speed, recorded_at
		FROM location_history
		WHERE trip_id = $1
		ORDER BY recorded_at DESC
		LIMIT $2`

	rows, err := r.db.Query(ctx, query, tripID, limit)
	if err != nil {
		return nil, fmt.Errorf("failed to get location history: %w", err)
	}
	defer rows.Close()

	var history []models.LocationHistory
	for rows.Next() {
		var h models.LocationHistory
		err := rows.Scan(&h.ID, &h.TripID, &h.Latitude, &h.Longitude, &h.Accuracy, &h.Speed, &h.RecordedAt)
		if err != nil {
			return nil, fmt.Errorf("failed to scan location history: %w", err)
		}
		history = append(history, h)
	}

	return history, nil
}
