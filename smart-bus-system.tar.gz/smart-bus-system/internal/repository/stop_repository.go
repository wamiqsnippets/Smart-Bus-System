package repository

import (
	"context"
	"errors"
	"fmt"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
	"smart-bus-system/internal/models"
	"smart-bus-system/internal/utils"
)

type stopRepository struct {
	db *pgxpool.Pool
}

func NewStopRepository(db *pgxpool.Pool) StopRepository {
	return &stopRepository{db: db}
}

func (r *stopRepository) Create(ctx context.Context, stop *models.BusStop) error {
	query := `
		INSERT INTO bus_stops (id, name, latitude, longitude, geofence_radius, stop_order, estimated_students, address, is_active)
		VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
		RETURNING created_at, updated_at`

	err := r.db.QueryRow(ctx, query,
		stop.ID,
		stop.Name,
		stop.Latitude,
		stop.Longitude,
		stop.GeofenceRadius,
		stop.StopOrder,
		stop.EstimatedStudents,
		stop.Address,
		stop.IsActive,
	).Scan(&stop.CreatedAt, &stop.UpdatedAt)

	if err != nil {
		return fmt.Errorf("failed to create stop: %w", err)
	}

	return nil
}

func (r *stopRepository) GetByID(ctx context.Context, id string) (*models.BusStop, error) {
	query := `
		SELECT id, name, latitude, longitude, geofence_radius, stop_order, estimated_students, address, is_active, created_at, updated_at
		FROM bus_stops
		WHERE id = $1`

	var stop models.BusStop
	err := r.db.QueryRow(ctx, query, id).Scan(
		&stop.ID,
		&stop.Name,
		&stop.Latitude,
		&stop.Longitude,
		&stop.GeofenceRadius,
		&stop.StopOrder,
		&stop.EstimatedStudents,
		&stop.Address,
		&stop.IsActive,
		&stop.CreatedAt,
		&stop.UpdatedAt,
	)

	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return nil, fmt.Errorf("stop not found")
		}
		return nil, fmt.Errorf("failed to get stop: %w", err)
	}

	return &stop, nil
}

func (r *stopRepository) GetAll(ctx context.Context, activeOnly bool) ([]models.BusStop, error) {
	query := `
		SELECT id, name, latitude, longitude, geofence_radius, stop_order, estimated_students, address, is_active, created_at, updated_at
		FROM bus_stops`

	if activeOnly {
		query += " WHERE is_active = true"
	}

	rows, err := r.db.Query(ctx, query)
	if err != nil {
		return nil, fmt.Errorf("failed to get stops: %w", err)
	}
	defer rows.Close()

	return r.scanStops(rows)
}

func (r *stopRepository) GetAllOrdered(ctx context.Context, activeOnly bool) ([]models.BusStop, error) {
	query := `
		SELECT id, name, latitude, longitude, geofence_radius, stop_order, estimated_students, address, is_active, created_at, updated_at
		FROM bus_stops`

	if activeOnly {
		query += " WHERE is_active = true"
	}

	query += " ORDER BY stop_order ASC"

	rows, err := r.db.Query(ctx, query)
	if err != nil {
		return nil, fmt.Errorf("failed to get stops: %w", err)
	}
	defer rows.Close()

	return r.scanStops(rows)
}

func (r *stopRepository) Update(ctx context.Context, id string, stop *models.BusStop) error {
	query := `
		UPDATE bus_stops
		SET name = $2, latitude = $3, longitude = $4, geofence_radius = $5, 
		    stop_order = $6, estimated_students = $7, address = $8, is_active = $9
		WHERE id = $1
		RETURNING updated_at`

	err := r.db.QueryRow(ctx, query,
		id,
		stop.Name,
		stop.Latitude,
		stop.Longitude,
		stop.GeofenceRadius,
		stop.StopOrder,
		stop.EstimatedStudents,
		stop.Address,
		stop.IsActive,
	).Scan(&stop.UpdatedAt)

	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return fmt.Errorf("stop not found")
		}
		return fmt.Errorf("failed to update stop: %w", err)
	}

	return nil
}

func (r *stopRepository) Delete(ctx context.Context, id string) error {
	query := `DELETE FROM bus_stops WHERE id = $1`

	result, err := r.db.Exec(ctx, query, id)
	if err != nil {
		return fmt.Errorf("failed to delete stop: %w", err)
	}

	if result.RowsAffected() == 0 {
		return fmt.Errorf("stop not found")
	}

	return nil
}

// FindNearbyStops finds all stops within the specified radius of a location
// Uses bounding box for initial filtering, then precise distance calculation
func (r *stopRepository) FindNearbyStops(ctx context.Context, lat, lon, radiusMeters float64) ([]models.BusStop, error) {
	// Calculate bounding box for efficient query
	minLat, maxLat, minLon, maxLon := utils.BoundingBox(lat, lon, radiusMeters)

	query := `
		SELECT id, name, latitude, longitude, geofence_radius, stop_order, estimated_students, address, is_active, created_at, updated_at
		FROM bus_stops
		WHERE is_active = true
		  AND latitude BETWEEN $1 AND $2
		  AND longitude BETWEEN $3 AND $4`

	rows, err := r.db.Query(ctx, query, minLat, maxLat, minLon, maxLon)
	if err != nil {
		return nil, fmt.Errorf("failed to find nearby stops: %w", err)
	}
	defer rows.Close()

	allStops, err := r.scanStops(rows)
	if err != nil {
		return nil, err
	}

	// Filter by precise distance using Haversine formula
	var nearbyStops []models.BusStop
	for _, stop := range allStops {
		distance := utils.HaversineDistance(lat, lon, stop.Latitude, stop.Longitude)
		// Use the stop's own geofence radius, with fallback to the search radius
		checkRadius := float64(stop.GeofenceRadius)
		if checkRadius == 0 {
			checkRadius = radiusMeters
		}
		if distance <= checkRadius {
			nearbyStops = append(nearbyStops, stop)
		}
	}

	return nearbyStops, nil
}

func (r *stopRepository) scanStops(rows pgx.Rows) ([]models.BusStop, error) {
	var stops []models.BusStop
	for rows.Next() {
		var stop models.BusStop
		err := rows.Scan(
			&stop.ID,
			&stop.Name,
			&stop.Latitude,
			&stop.Longitude,
			&stop.GeofenceRadius,
			&stop.StopOrder,
			&stop.EstimatedStudents,
			&stop.Address,
			&stop.IsActive,
			&stop.CreatedAt,
			&stop.UpdatedAt,
		)
		if err != nil {
			return nil, fmt.Errorf("failed to scan stop: %w", err)
		}
		stops = append(stops, stop)
	}

	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("rows iteration error: %w", err)
	}

	return stops, nil
}
