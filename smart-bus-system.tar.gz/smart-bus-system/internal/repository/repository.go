package repository

import (
	"context"
	"time"

	"smart-bus-system/internal/models"
)

type BusRepository interface {
	Create(ctx context.Context, bus *models.Bus) error
	GetByID(ctx context.Context, id string) (*models.Bus, error)
	GetByBusNumber(ctx context.Context, busNumber string) (*models.Bus, error)
	GetAll(ctx context.Context, activeOnly bool) ([]models.Bus, error)
	Update(ctx context.Context, id string, bus *models.Bus) error
	Delete(ctx context.Context, id string) error
}

type StopRepository interface {
	Create(ctx context.Context, stop *models.BusStop) error
	GetByID(ctx context.Context, id string) (*models.BusStop, error)
	GetAll(ctx context.Context, activeOnly bool) ([]models.BusStop, error)
	GetAllOrdered(ctx context.Context, activeOnly bool) ([]models.BusStop, error)
	Update(ctx context.Context, id string, stop *models.BusStop) error
	Delete(ctx context.Context, id string) error
	FindNearbyStops(ctx context.Context, lat, lon, radiusMeters float64) ([]models.BusStop, error)
}

type TripRepository interface {
	Create(ctx context.Context, trip *models.Trip) error
	GetByID(ctx context.Context, id string) (*models.Trip, error)
	GetByBusAndDate(ctx context.Context, busID string, tripDate time.Time, tripType models.TripType) (*models.Trip, error)
	GetTripsByDate(ctx context.Context, tripDate time.Time) ([]models.TripWithDetails, error)
	GetActiveTripForBus(ctx context.Context, busID string) (*models.Trip, error)
	Update(ctx context.Context, id string, trip *models.Trip) error
	UpdateLocation(ctx context.Context, id string, lat, lon float64) error
	UpdateStatus(ctx context.Context, id string, status models.TripStatus) error
	Delete(ctx context.Context, id string) error
	
	// Location history
	SaveLocationHistory(ctx context.Context, history *models.LocationHistory) error
	GetLocationHistory(ctx context.Context, tripID string, limit int) ([]models.LocationHistory, error)
}

type StudentCountRepository interface {
	Create(ctx context.Context, count *models.StudentCount) error
	GetByID(ctx context.Context, id string) (*models.StudentCount, error)
	GetByTripAndStop(ctx context.Context, tripID, stopID string) (*models.StudentCount, error)
	GetByTripID(ctx context.Context, tripID string) ([]models.StudentCountWithStop, error)
	Update(ctx context.Context, id string, count *models.StudentCount) error
	Delete(ctx context.Context, id string) error
	
	// Geofence events
	SaveGeofenceEvent(ctx context.Context, event *models.GeofenceEvent) error
	GetRecentGeofenceEvents(ctx context.Context, tripID, stopID string, eventType string, windowSeconds int) ([]models.GeofenceEvent, error)
	HasRecentEntry(ctx context.Context, tripID, stopID string, windowSeconds int) (bool, error)
}

type Repository struct {
	Bus          BusRepository
	Stop         StopRepository
	Trip         TripRepository
	StudentCount StudentCountRepository
}
