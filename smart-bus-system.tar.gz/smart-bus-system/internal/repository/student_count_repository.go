package repository

import (
	"context"
	"errors"
	"fmt"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
	"smart-bus-system/internal/models"
)

type studentCountRepository struct {
	db *pgxpool.Pool
}

func NewStudentCountRepository(db *pgxpool.Pool) StudentCountRepository {
	return &studentCountRepository{db: db}
}

func (r *studentCountRepository) Create(ctx context.Context, count *models.StudentCount) error {
	query := `
		INSERT INTO student_counts (id, trip_id, stop_id, students_boarded, students_alighted, manual_override, arrival_time, departure_time, notes)
		VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
		RETURNING created_at, updated_at`

	err := r.db.QueryRow(ctx, query,
		count.ID,
		count.TripID,
		count.StopID,
		count.StudentsBoarded,
		count.StudentsAlighted,
		count.ManualOverride,
		count.ArrivalTime,
		count.DepartureTime,
		count.Notes,
	).Scan(&count.CreatedAt, &count.UpdatedAt)

	if err != nil {
		return fmt.Errorf("failed to create student count: %w", err)
	}

	return nil
}

func (r *studentCountRepository) GetByID(ctx context.Context, id string) (*models.StudentCount, error) {
	query := `
		SELECT id, trip_id, stop_id, students_boarded, students_alighted, manual_override, 
		       arrival_time, departure_time, notes, created_at, updated_at
		FROM student_counts
		WHERE id = $1`

	var count models.StudentCount
	err := r.db.QueryRow(ctx, query, id).Scan(
		&count.ID,
		&count.TripID,
		&count.StopID,
		&count.StudentsBoarded,
		&count.StudentsAlighted,
		&count.ManualOverride,
		&count.ArrivalTime,
		&count.DepartureTime,
		&count.Notes,
		&count.CreatedAt,
		&count.UpdatedAt,
	)

	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return nil, fmt.Errorf("student count not found")
		}
		return nil, fmt.Errorf("failed to get student count: %w", err)
	}

	return &count, nil
}

func (r *studentCountRepository) GetByTripAndStop(ctx context.Context, tripID, stopID string) (*models.StudentCount, error) {
	query := `
		SELECT id, trip_id, stop_id, students_boarded, students_alighted, manual_override, 
		       arrival_time, departure_time, notes, created_at, updated_at
		FROM student_counts
		WHERE trip_id = $1 AND stop_id = $2`

	var count models.StudentCount
	err := r.db.QueryRow(ctx, query, tripID, stopID).Scan(
		&count.ID,
		&count.TripID,
		&count.StopID,
		&count.StudentsBoarded,
		&count.StudentsAlighted,
		&count.ManualOverride,
		&count.ArrivalTime,
		&count.DepartureTime,
		&count.Notes,
		&count.CreatedAt,
		&count.UpdatedAt,
	)

	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return nil, fmt.Errorf("student count not found")
		}
		return nil, fmt.Errorf("failed to get student count: %w", err)
	}

	return &count, nil
}

func (r *studentCountRepository) GetByTripID(ctx context.Context, tripID string) ([]models.StudentCountWithStop, error) {
	query := `
		SELECT sc.id, sc.trip_id, sc.stop_id, sc.students_boarded, sc.students_alighted, 
		       sc.manual_override, sc.arrival_time, sc.departure_time, sc.notes, sc.created_at, sc.updated_at,
		       bs.name, bs.latitude, bs.longitude, bs.stop_order
		FROM student_counts sc
		JOIN bus_stops bs ON sc.stop_id = bs.id
		WHERE sc.trip_id = $1
		ORDER BY bs.stop_order ASC`

	rows, err := r.db.Query(ctx, query, tripID)
	if err != nil {
		return nil, fmt.Errorf("failed to get student counts: %w", err)
	}
	defer rows.Close()

	var counts []models.StudentCountWithStop
	for rows.Next() {
		var count models.StudentCountWithStop
		err := rows.Scan(
			&count.ID,
			&count.TripID,
			&count.StopID,
			&count.StudentsBoarded,
			&count.StudentsAlighted,
			&count.ManualOverride,
			&count.ArrivalTime,
			&count.DepartureTime,
			&count.Notes,
			&count.CreatedAt,
			&count.UpdatedAt,
			&count.StopName,
			&count.StopLatitude,
			&count.StopLongitude,
			&count.StopOrder,
		)
		if err != nil {
			return nil, fmt.Errorf("failed to scan student count: %w", err)
		}
		counts = append(counts, count)
	}

	return counts, nil
}

func (r *studentCountRepository) Update(ctx context.Context, id string, count *models.StudentCount) error {
	query := `
		UPDATE student_counts
		SET students_boarded = $2, students_alighted = $3, manual_override = $4, 
		    departure_time = $5, notes = $6
		WHERE id = $1
		RETURNING updated_at`

	err := r.db.QueryRow(ctx, query,
		id,
		count.StudentsBoarded,
		count.StudentsAlighted,
		count.ManualOverride,
		count.DepartureTime,
		count.Notes,
	).Scan(&count.UpdatedAt)

	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return fmt.Errorf("student count not found")
		}
		return fmt.Errorf("failed to update student count: %w", err)
	}

	return nil
}

func (r *studentCountRepository) Delete(ctx context.Context, id string) error {
	query := `DELETE FROM student_counts WHERE id = $1`

	result, err := r.db.Exec(ctx, query, id)
	if err != nil {
		return fmt.Errorf("failed to delete student count: %w", err)
	}

	if result.RowsAffected() == 0 {
		return fmt.Errorf("student count not found")
	}

	return nil
}

// Geofence event tracking for duplicate detection
func (r *studentCountRepository) SaveGeofenceEvent(ctx context.Context, event *models.GeofenceEvent) error {
	query := `
		INSERT INTO geofence_events (id, trip_id, stop_id, event_type, detected_at, latitude, longitude)
		VALUES ($1, $2, $3, $4, $5, $6, $7)`

	_, err := r.db.Exec(ctx, query,
		event.ID,
		event.TripID,
		event.StopID,
		event.EventType,
		event.DetectedAt,
		event.Latitude,
		event.Longitude,
	)

	if err != nil {
		return fmt.Errorf("failed to save geofence event: %w", err)
	}

	return nil
}

func (r *studentCountRepository) GetRecentGeofenceEvents(ctx context.Context, tripID, stopID string, eventType string, windowSeconds int) ([]models.GeofenceEvent, error) {
	query := `
		SELECT id, trip_id, stop_id, event_type, detected_at, latitude, longitude
		FROM geofence_events
		WHERE trip_id = $1 AND stop_id = $2 AND event_type = $3
		  AND detected_at > NOW() - INTERVAL '1 second' * $4
		ORDER BY detected_at DESC`

	rows, err := r.db.Query(ctx, query, tripID, stopID, eventType, windowSeconds)
	if err != nil {
		return nil, fmt.Errorf("failed to get recent geofence events: %w", err)
	}
	defer rows.Close()

	var events []models.GeofenceEvent
	for rows.Next() {
		var event models.GeofenceEvent
		err := rows.Scan(
			&event.ID,
			&event.TripID,
			&event.StopID,
			&event.EventType,
			&event.DetectedAt,
			&event.Latitude,
			&event.Longitude,
		)
		if err != nil {
			return nil, fmt.Errorf("failed to scan geofence event: %w", err)
		}
		events = append(events, event)
	}

	return events, nil
}

// HasRecentEntry checks if there's a recent "enter" event within the time window
// This is used for duplicate detection - O(1) query with indexed lookup
func (r *studentCountRepository) HasRecentEntry(ctx context.Context, tripID, stopID string, windowSeconds int) (bool, error) {
	query := `
		SELECT EXISTS(
			SELECT 1 FROM geofence_events
			WHERE trip_id = $1 AND stop_id = $2 AND event_type = 'enter'
			  AND detected_at > NOW() - INTERVAL '1 second' * $3
		)`

	var exists bool
	err := r.db.QueryRow(ctx, query, tripID, stopID, windowSeconds).Scan(&exists)
	if err != nil {
		return false, fmt.Errorf("failed to check recent entry: %w", err)
	}

	return exists, nil
}
