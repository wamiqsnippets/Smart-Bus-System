# Technical Architecture & Implementation Details

## System Architecture

### Layered Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     Presentation Layer                       │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  HTTP Handlers + WebSocket Handler + Middleware     │    │
│  └─────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────┘
                           ▼
┌─────────────────────────────────────────────────────────────┐
│                      Business Logic Layer                    │
│  ┌──────────────┐  ┌──────────────┐  ┌─────────────────┐   │
│  │ Trip Service │  │   Geofence   │  │    WebSocket    │   │
│  │              │  │    Service   │  │     Service     │   │
│  └──────────────┘  └──────────────┘  └─────────────────┘   │
└─────────────────────────────────────────────────────────────┘
                           ▼
┌─────────────────────────────────────────────────────────────┐
│                      Data Access Layer                       │
│  ┌──────────────┐  ┌──────────────┐  ┌─────────────────┐   │
│  │     Bus      │  │     Stop     │  │      Trip       │   │
│  │  Repository  │  │  Repository  │  │   Repository    │   │
│  └──────────────┘  └──────────────┘  └─────────────────┘   │
│  ┌──────────────────────────────────────────────────────┐   │
│  │         Student Count Repository                     │   │
│  └──────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
                           ▼
┌─────────────────────────────────────────────────────────────┐
│                     PostgreSQL Database                      │
│  ┌────────┐  ┌────────┐  ┌────────┐  ┌──────────────────┐  │
│  │ Buses  │  │ Stops  │  │ Trips  │  │  Student Counts  │  │
│  └────────┘  └────────┘  └────────┘  └──────────────────┘  │
│  ┌─────────────────┐  ┌──────────────────────────────────┐  │
│  │ Location History│  │    Geofence Events               │  │
│  └─────────────────┘  └──────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

## Geofencing Implementation

### Core Algorithm

```go
// 1. Location Update Received
func UpdateLocation(lat, lon float64) {
    // 2. Save to database with timestamp
    SaveLocationHistory(lat, lon, time.Now())
    
    // 3. Find nearby stops using bounding box
    minLat, maxLat, minLon, maxLon := CalculateBoundingBox(lat, lon, radius)
    stops := FindStopsInBoundingBox(minLat, maxLat, minLon, maxLon)
    
    // 4. Calculate precise distance for each stop
    for stop in stops {
        distance := HaversineDistance(lat, lon, stop.lat, stop.lon)
        
        // 5. Check if within geofence
        if distance <= stop.geofence_radius {
            // 6. Check duplicate detection
            if !HasRecentEntry(tripID, stopID, timeWindow) {
                // 7. This is a new valid detection
                detectedStops.append(stop)
            }
        }
    }
    
    // 8. Return detected stops to client
    return detectedStops
}
```

### Haversine Formula Implementation

Used for calculating great-circle distance between two points on Earth:

```go
func HaversineDistance(lat1, lon1, lat2, lon2 float64) float64 {
    // Convert to radians
    lat1Rad := lat1 * π / 180
    lat2Rad := lat2 * π / 180
    deltaLat := (lat2 - lat1) * π / 180
    deltaLon := (lon2 - lon1) * π / 180
    
    // Haversine formula
    a := sin²(deltaLat/2) + cos(lat1Rad) * cos(lat2Rad) * sin²(deltaLon/2)
    c := 2 * atan2(√a, √(1-a))
    
    // Distance in meters
    return 6371000 * c
}
```

**Complexity**: O(1) - constant time
**Accuracy**: ±0.5% for distances up to 1000km

### Duplicate Detection

#### Two-Layer Approach:

1. **In-Memory Cache** (Primary - Fast)
   - sync.Map for concurrent access
   - Key: "tripID:stopID"
   - Value: timestamp of last detection
   - O(1) lookup
   - Cleaned every 5 minutes

2. **Database Check** (Secondary - Reliable)
   - Geofence events table with indexed lookup
   - Query: Recent "enter" events within time window
   - Indexed on (trip_id, stop_id, event_type, detected_at)
   - O(log n) with B-tree index

```sql
-- Optimized query with index
SELECT EXISTS(
    SELECT 1 FROM geofence_events
    WHERE trip_id = $1 
      AND stop_id = $2 
      AND event_type = 'enter'
      AND detected_at > NOW() - INTERVAL '300 seconds'
)
```

## Database Optimizations

### Indexing Strategy

```sql
-- Buses
CREATE INDEX idx_buses_bus_number ON buses(bus_number);
CREATE INDEX idx_buses_is_active ON buses(is_active);

-- Bus Stops (Spatial indexing)
CREATE INDEX idx_stops_coordinates ON bus_stops(latitude, longitude);
CREATE INDEX idx_stops_stop_order ON bus_stops(stop_order);

-- Trips (Composite indexes for common queries)
CREATE INDEX idx_trips_bus_id ON trips(bus_id);
CREATE INDEX idx_trips_trip_date ON trips(trip_date);
CREATE INDEX idx_trips_bus_date_type ON trips(bus_id, trip_date, trip_type);

-- Student Counts
CREATE INDEX idx_student_counts_trip_stop ON student_counts(trip_id, stop_id);

-- Geofence Events (Duplicate detection)
CREATE INDEX idx_geofence_events_trip_stop_type 
    ON geofence_events(trip_id, stop_id, event_type);
CREATE INDEX idx_geofence_events_detected_at 
    ON geofence_events(detected_at DESC);
```

### Query Optimization Examples

#### Before Optimization:
```sql
-- Scans entire table: O(n)
SELECT * FROM bus_stops 
WHERE latitude BETWEEN 28.5 AND 28.7 
  AND longitude BETWEEN 77.1 AND 77.3;
```

#### After Optimization:
```sql
-- Uses bounding box + index: O(log n)
SELECT * FROM bus_stops 
WHERE latitude BETWEEN $1 AND $2 
  AND longitude BETWEEN $3 AND $4
  AND is_active = true;
```

### Connection Pooling

```go
poolConfig.MaxConns = 25          // Maximum connections
poolConfig.MinConns = 5           // Minimum idle connections
poolConfig.MaxConnLifetime = 5min // Connection reuse time
poolConfig.HealthCheckPeriod = 1min
```

**Benefits**:
- Reduced connection overhead
- Better resource utilization
- Automatic health checking
- Connection reuse

## Concurrency Handling

### 1. Database Level
- Uses pgx connection pool (thread-safe)
- Prepared statements prevent SQL injection
- Context timeouts prevent hung queries

### 2. WebSocket Broadcasting
```go
type WebSocketService struct {
    clients    map[*websocket.Conn]bool
    clientsMux sync.RWMutex  // Reader-writer lock
}

func (s *WebSocketService) broadcast(message) {
    s.clientsMux.RLock()  // Multiple readers allowed
    defer s.clientsMux.RUnlock()
    
    for client := range s.clients {
        client.WriteMessage(message)  // Concurrent writes
    }
}
```

### 3. Geofence Cache
```go
type GeofenceService struct {
    recentDetections sync.Map  // Concurrent-safe map
}

func (s *GeofenceService) IsStopAlreadyVisited(tripID, stopID) bool {
    cacheKey := fmt.Sprintf("%s:%s", tripID, stopID)
    
    // O(1) concurrent-safe lookup
    if lastDetection, ok := s.recentDetections.Load(cacheKey); ok {
        return time.Since(lastDetection.(time.Time)) < window
    }
    return false
}
```

## Error Handling Strategy

### 1. Graceful Degradation
```go
// Location history failure shouldn't block location update
if err := SaveLocationHistory(ctx, history); err != nil {
    log.Warn().Err(err).Msg("Failed to save location history")
    // Continue processing - don't return error
}
```

### 2. Context Timeouts
```go
ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
defer cancel()

result, err := repository.Query(ctx, query)
if err != nil {
    if errors.Is(err, context.DeadlineExceeded) {
        return ErrQueryTimeout
    }
    return err
}
```

### 3. Structured Logging
```go
log.Error().
    Err(err).
    Str("trip_id", tripID).
    Str("stop_id", stopID).
    Float64("latitude", lat).
    Float64("longitude", lon).
    Msg("Failed to detect stops")
```

## Performance Characteristics

### Time Complexity

| Operation | Complexity | Notes |
|-----------|-----------|-------|
| Location Update | O(1) | Direct database write |
| Stop Detection | O(n log n) | n = stops in bounding box |
| Duplicate Check | O(1) avg | In-memory cache hit |
| Distance Calculation | O(1) | Haversine formula |
| Student Count Record | O(1) | Indexed insert |

### Space Complexity

| Component | Memory Usage | Notes |
|-----------|--------------|-------|
| Connection Pool | ~10MB | 25 connections |
| WebSocket Clients | ~5KB per client | 100 clients = 500KB |
| Geofence Cache | ~100 bytes per entry | 1000 entries = 100KB |
| Application | ~50MB | Base runtime |
| **Total (typical)** | **~100MB** | Under normal load |

## Security Implementation

### 1. SQL Injection Prevention
```go
// ✅ SAFE: Using parameterized queries
query := "SELECT * FROM trips WHERE id = $1"
row := db.QueryRow(ctx, query, tripID)

// ❌ UNSAFE: String concatenation
query := "SELECT * FROM trips WHERE id = '" + tripID + "'"
```

### 2. Input Validation
```go
type UpdateLocationRequest struct {
    Latitude  float64 `json:"latitude" validate:"required,min=-90,max=90"`
    Longitude float64 `json:"longitude" validate:"required,min=-180,max=180"`
}
```

### 3. Context-based Request Cancellation
```go
func (h *Handler) UpdateLocation(w http.ResponseWriter, r *http.Request) {
    ctx := r.Context()  // Automatically cancelled if client disconnects
    
    result, err := service.UpdateLocation(ctx, data)
    if err != nil {
        if errors.Is(err, context.Canceled) {
            return  // Client disconnected, don't process
        }
        // Handle other errors
    }
}
```

## Scalability Considerations

### Horizontal Scaling
- **Stateless API**: Can run multiple instances behind load balancer
- **WebSocket**: Use Redis pub/sub for cross-instance messaging
- **Database**: Read replicas for query scaling

### Vertical Scaling
- **Connection Pool**: Increase max connections
- **CPU**: Haversine calculations are CPU-bound
- **Memory**: In-memory cache can grow with traffic

### Partitioning Strategy
```sql
-- Partition location_history by date for performance
CREATE TABLE location_history_2025_01 PARTITION OF location_history
FOR VALUES FROM ('2025-01-01') TO ('2025-02-01');
```

## Monitoring & Observability

### Metrics to Track
1. **Request Latency**
   - p50, p95, p99 response times
   - Per endpoint breakdown

2. **Database Performance**
   - Query execution time
   - Connection pool utilization
   - Index hit ratio

3. **Geofencing Accuracy**
   - Detection success rate
   - False positive rate
   - Duplicate detection rate

4. **System Resources**
   - CPU usage
   - Memory consumption
   - Network I/O

### Health Checks
```go
GET /api/v1/health

{
  "database": "healthy",
  "websocket_clients": 42,
  "cache_entries": 156,
  "uptime_seconds": 86400
}
```

## Deployment Best Practices

1. **Use Connection Pooling**: Already implemented with pgx
2. **Enable Query Logging**: For debugging in development
3. **Set Resource Limits**: CPU and memory in production
4. **Use Load Balancer**: For high availability
5. **Implement Rate Limiting**: Prevent abuse
6. **Enable HTTPS**: Encrypt data in transit
7. **Database Backups**: Automated daily backups
8. **Monitor Logs**: Centralized logging (ELK, Datadog)

## Testing Strategy

### Unit Tests
- Repository layer with mock database
- Service layer with mock repositories
- Utility functions (Haversine, bounding box)

### Integration Tests
- API endpoints with test database
- WebSocket connections
- Geofence detection end-to-end

### Performance Tests
- Load testing with k6 or Apache JMeter
- Stress testing concurrent requests
- Memory leak detection

---

**Note**: This system is designed for production use with focus on:
- ✅ Performance (O(1) and O(log n) operations)
- ✅ Reliability (duplicate detection, error handling)
- ✅ Scalability (stateless, connection pooling)
- ✅ Maintainability (clean architecture, structured logging)
- ✅ Security (prepared statements, validation, HTTPS)
